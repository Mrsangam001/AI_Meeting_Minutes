# Mini Project Report: AI Meeting Minutes System

## 1. Abstract
The AI Meeting Minutes system is a locally-hosted, privacy-first web application designed to automate the extraction of valuable information from meeting recordings. By integrating Automatic Speech Recognition (ASR), a Large Language Model (LLM), and Neural Machine Translation (NMT), the application converts audio into professional, structured meeting notes. This report details the architecture, component design, technologies used, and the underlying logic of the application.

## 2. Introduction
In professional and academic settings, meetings are a primary mode of collaboration. However, documenting these meetings is tedious and prone to manual errors or omissions. The objective of this project is to create an automated pipeline that can:
1. Listen to or transcribe a pre-recorded meeting.
2. Analyze the transcript to identify key topics, decisions, and action items.
3. Format the data into professional meeting minutes using an LLM.
4. Translate the output into various languages to support cross-cultural teams.

## 3. Technologies Used
### 3.1 Backend
- **Python (Flask):** Serves as the web framework, managing file uploads and API endpoints.
- **PyTorch:** The underlying deep learning framework executing the AI models.
- **Transformers (HuggingFace):** Library used to load and run the LLM and Translation models.

### 3.2 Artificial Intelligence Models
- **Transcription**: `OpenAI Whisper` via `Faster-Whisper` (CTranslate2 engine). A robust ASR model that handles various accents and background noises with float16/int8 quantization for performance.
- **Summarization**: `Qwen/Qwen1.5-0.5B-Chat`. A lightweight but highly capable instruct-tuned LLM that parses transcripts into structured Markdown using a professional meeting minutes template.
- **Translation**: `Helsinki-NLP/opus-mt-*` (MarianMT). A collection of neural machine translation models for high-quality text translation without relying on external APIs.

### 3.3 Frontend
- **HTML5/CSS3/Vanilla JS**: For a responsive, lightweight, and modern glassmorphism UI.
- **MediaRecorder API**: For capturing live microphone data directly in the browser.
- **html2pdf.js**: For client-side PDF generation of the finalized meeting minutes.
- **marked.js**: For rendering the Markdown output from the LLM into styled HTML.

## 4. System Architecture
The system employs a decoupled, API-driven architecture.

### 4.1 Frontend Flow
The web interface allows users to either upload an audio file (`.mp3`, `.wav`, etc.) or record audio directly. When submitted, the frontend packages the audio into a `FormData` object and POSTs it to the `/api/transcribe` endpoint. A progress bar tracks the initialization, transcription, and summarization phases.

### 4.2 Transcription Pipeline (`transcriber.py`)
Upon receiving the audio file, the Flask server triggers the `transcribe_audio` function. It loads the requested Whisper model size (cached in memory via `@lru_cache` to prevent reloading across requests), and processes the audio file. Hallucination loops are prevented by setting `condition_on_previous_text=False`, which ensures silence does not trigger the model to repeat previous tokens indefinitely. A Silero VAD (Voice Activity Detection) filter also strips dead air before inference. An `initial_prompt` biases the model's vocabulary toward meeting terminology.

### 4.3 Summarization & Translation Pipeline (`summarizer.py`)
The generated transcript text is POSTed to `/api/summarize`. Due to LLM context window limits, the summarizer employs an intelligent **semantic chunking technique**:
- If the text is short (<8000 characters), it is directly queried against the `Qwen` model with a structured system prompt (Executive Summary, Key Points, Decisions, Action Items).
- If the text is long, it is split into 6000-character chunks at sentence boundaries using regex (`re.split`), ensuring no sentence is broken mid-word. Each chunk is summarized individually. The summaries are then concatenated and passed back through the LLM for a final cohesive polish (Map-Reduce pattern).

Finally, if the user requested a non-English output, the result is processed through the appropriate MarianMT translation bridge before being returned to the frontend.

## 5. Implementation Details & Optimizations
- **Memory Management:** `@lru_cache` decorators are used on model loading functions with `maxsize=3`, ensuring the large tensors (Whisper, Qwen, MarianMT) are loaded into RAM/VRAM exactly once per model size across the application lifecycle.
- **Storage Management:** Uploaded audio files are assigned UUIDs to prevent naming collisions and are purged from the filesystem immediately after transcription using a `finally` block, preventing storage leaks.
- **Hardware Agnostic:** The application dynamically checks for `torch.cuda.is_available()` to utilize GPU acceleration (float16), while gracefully falling back to CPU with int8 quantization (via CTranslate2) if a GPU is not present.

## 6. Challenges Faced
The most significant challenge was processing long meeting transcripts. LLMs have a fixed context window — feeding too much text results in Out-Of-Memory (OOM) errors or truncated output. The map-reduce style semantic chunking algorithm in `summarizer.py` resolves this by splitting text at sentence boundaries, processing each chunk independently, and then combining the results into final polished minutes. This ensures no context is lost regardless of meeting length.

## 7. Conclusion
The AI Meeting Minutes system successfully demonstrates how multiple specialized, open-source AI models can be orchestrated within a single local environment to build a useful enterprise tool. By bypassing expensive cloud API calls and prioritizing user privacy, it offers a compelling alternative to subscription-based SaaS products for meeting documentation.
