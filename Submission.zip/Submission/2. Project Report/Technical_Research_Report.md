# AI Meeting Minutes: Comprehensive Technical Research & Architecture Report

## 1. Executive Summary

The **AI Meeting Minutes** application is a decoupled, privacy-first, locally-hosted web application designed to completely automate the extraction of valuable intelligence from digital meeting audio. By integrating an Automatic Speech Recognition (ASR) engine, a Large Language Model (LLM), and Neural Machine Translation (NMT) networks, the system converts unstructured audio recordings into formulated, actionable text documents in multiple global languages.

Unlike standard enterprise workflows that pipe highly sensitive corporate audio to third-party cloud wrappers, this project guarantees absolute data privacy by running all inference locally on consumer-grade hardware, gracefully decaying to CPU-only INT8 quantized inference when GPU (CUDA) acceleration is unavailable.

---

## 2. Platform Architecture

The architecture functions as a three-tier Web Application, ensuring high modularity and separation of concerns.

### 2.1 Backend Orchestration (Flask API)
The central nervous system of the application relies on **Flask**, a micro-framework written in Python.
- **RESTful Endpoints**: The backend isolates logic entirely by exposing two distinct endpoints:
  - `/api/transcribe` (Multipart/form-data for Audio Ingestion)
  - `/api/summarize` (JSON payload containing raw transcripts and language target directives)
- **CORS Handling**: `flask_cors` dynamically guards API origins against Cross-Site Request Forgery (CSRF).
- **Concurrency & Security**: Audio artifacts are written to an isolated `uploads/` volume, assigned unguessable UUIDs (`uuid.uuid4().hex`) to prevent race-condition collision in multi-user environments, and are aggressively garbage-collected via a `finally` block irrespective of transcription success or failure.
- **Payload Limits**: Network constraints are strictly enforced (`100MB` limit) to prevent Denial of Service via artificially large audio uploads.

### 2.2 Deep Learning Management
The heaviest computational burden is the sheer magnitude of tensor variables necessary for Deep Learning models. The codebase resolves Memory Leaks/OOM states through heavy reliance on Python's `functools.lru_cache(maxsize=3)`. Wrapping model instantiations ensures that the multi-gigabyte model files (Whisper, Qwen, MarianMT) are loaded into Volatile Memory exactly once per model size across the application lifecycle.

---

## 3. Subsystem 1: Audio Processing & Intelligibility (ASR)

The `transcriber.py` module uses **OpenAI Whisper** via the **Faster-Whisper** library (backed by the CTranslate2 C++ inference engine) for high-speed, quantized multilingual audio transcription.

### 3.1 Hallucination Loop Prevention
Standard Whisper behavior includes severe hallucination defects during periods of audio silence — when no one is speaking, the auto-regressive decoder repeatedly outputs overlapping nonsensical tokens instead of pausing. The application engineers a bypass by explicitly passing `condition_on_previous_text=False`, commanding the model to evaluate each audio window in isolation rather than conditioning on recursive historical token output.

Additionally, a **Silero Voice Activity Detection (VAD) filter** is applied with `vad_filter=True`, which strips all silent regions from the audio matrix before the ASR model evaluates them — providing a secondary guarantee against hallucination.

### 3.2 Context Vector Biasing
To further hone accuracy, the ASR pipeline is seeded with an `initial_prompt`: *"This is a formal corporate meeting recording. The speakers are discussing critical business topics."*

This subtly biases the statistical likelihood of the token matrix, conditioning the output to favour corporate terminology, standard conversational syntax, and meeting-specific jargon over generic vocabulary.

### 3.3 Performance via CTranslate2
The Faster-Whisper library uses **CTranslate2**, a custom C++ inference engine optimised for Transformer architectures. On GPU hardware, it uses **float16 (FP16)** quantization, doubling throughput. On CPU-only hardware, it collapses to **int8** quantization, achieving roughly 4x the speed of standard PyTorch Whisper at half the memory footprint.

---

## 4. Subsystem 2: Natural Language Processing (LLM)

The cognitive processing is housed inside `summarizer.py`, driving actionable meaning from raw transcript paragraphs. It operates on a quantized **Qwen/Qwen1.5-0.5B-Chat** instruct-tuned LLM via the HuggingFace `transformers` pipeline.

### 4.1 Model Selection: Qwen1.5-0.5B-Chat
`Qwen1.5-0.5B-Chat` is a 0.5 Billion parameter instruct-tuned language model from Alibaba Cloud. Its small parameter count makes it viable on consumer CPU hardware while its instruction-following capability allows structured Markdown output (Executive Summary, Key Discussion Points, Decisions Made, Action Items) via system prompts.

### 4.2 The Map-Reduce Chunking Problem
The most critical engineering problem solved is **Context Window Exhaustion**. Generative LLMs crash or truncate data if fed a prompt longer than their maximum token window (a 2-hour meeting transcript can exceed this easily).

To resolve this, the system evaluates string length:
- If a transcription contains **< 8000 characters**, it is sent directly to Qwen with a structured system prompt.
- If **≥ 8000 characters**, the script drops into **Semantic Map-Reduce execution**:
  - **Map Phase**: The text is split at explicit punctuation boundaries (`.`, `?`, `\n`) using Python's `re.split` regex, ensuring no sentence is broken mid-word. Chunks are capped at 6000 characters. Each chunk is independently processed by Qwen to extract localised discussion points and action items.
  - **Reduce Phase**: All chunk summaries are concatenated and fed back through Qwen with formatting instructions, producing the final polished Markdown minutes document.

### 4.3 Translation Fallbacks (Neural Machine Translation)
Because small LLMs degrade in reasoning quality when processing non-English input, a bridging structure is used:
1. If the input audio is non-English (detected via Whisper's `info.language`), a `Helsinki-NLP/opus-mt` MarianMT instance translates the raw transcript to English before summarisation.
2. English input guarantees best performance from Qwen during Markdown structuring.
3. If the user interface requests a localised destination language (e.g., Spanish, Japanese), the finalised Markdown runs through MarianMT a final time to produce the translated output.

---

## 5. UI/UX Client Interaction Model

The interface in `public/` uses only Vanilla CSS and JavaScript, avoiding the heavy footprint of React or Vue frameworks.

### 5.1 Live Recording via MediaRecorder API
Instead of requiring local audio file uploads, the JavaScript securely queries `navigator.mediaDevices.getUserMedia()`, creating a live browser microphone stream. Binary audio data is chunked into arrays and encoded into `.webm` blobs upon session termination, then transmitted to the Flask server via `FormData` as if it were a standard file upload.

### 5.2 Client-Side PDF Render Pipeline
PDF rendering is fully offloaded to the client browser:
- The LLM's Markdown output is rendered into styled HTML by `marked.min.js`.
- When "Export to PDF" is clicked, `html2pdf.js` uses the user's local GPU to render the DOM canvas and emit a PDF blob — bypassing the need for server-side LaTeX or ReportLab installations.
- The PDF bytes are base64-encoded and POSTed back to `/api/save_pdf`, which saves the file directly to the project folder and auto-opens it.

---

## 6. Future Implementations & Scale

This application has several primary vectors available for direct integration:

1. **Speaker Diarization**: Importing `pyannote.audio` for waveform pitch-based speaker segmentation, enabling transcripts to independently label dialogue (e.g., *Speaker A*: ..., *Speaker B*: ...).
2. **WebSocket Streaming**: Converting the RESTful batch-upload endpoint into an open WebSocket stream for real-time live transcript display during active meetings.
3. **Retrieval-Augmented Generation (RAG)**: Binding finished meeting minutes to embedded ChromaDB/Milvus vector clusters, allowing semantic search and natural language querying across an organisation's entire meeting history.
